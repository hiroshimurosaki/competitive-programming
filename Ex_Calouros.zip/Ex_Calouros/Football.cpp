#include <bits/stdc++.h>

using namespace std;

int main(){

    string jogadores;
    int seq = 1;

    cin >> jogadores;

    for(int i = 1; i < jogadores.size(); i++){
        if(jogadores[i-1] == jogadores[i]){
            seq++;
            if(seq >= 7){
                cout << "YES" << endl;
                return 0;
            }
        } else {
            seq = 1;
        }
    }

    cout << "NO" << endl;

    return 0;

}