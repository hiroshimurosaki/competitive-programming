#include <bits/stdc++.h>

using namespace std;

int main(){

    long long d, n;

    cin >> d >> n;

    d=n;

    for(int i=1;i<=9;i++){

        cout << (d i *10 +99)/100 << " ";

    }
    cout << endl;

    return 0;

} 