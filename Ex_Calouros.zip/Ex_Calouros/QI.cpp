#include <bits/stdc++.h>

using namespace std;

int main(){

    int n;
    int pares = 0;
    int impares = 0;
    int pospar;
    int posimpar;
    int aux;

    cin >> n;

    for(int i=0; i<n; i++){
        cin >> aux;
        if(aux%2 == 0){
            pares++;
            pospar = i;
        } else {
            impares++;
            posimpar = i;
        }
    }

    if(pares>impares){
        cout << posimpar+1 << endl;
    } else {
        cout << pospar+1 << endl;
    }

} 