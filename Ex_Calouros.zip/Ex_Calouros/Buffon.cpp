#include <bits/stdc++.h>

using namespace std;

int main(){

    int n;
    cin >> n;
    int maior;
    int aux;
    int carlos;
    for(int i=0; i<n; i++){
        cin >> aux;
        if(i == 0){
            carlos = aux;
        }
        if(aux > maior){
            maior = aux;
        }
    }

    if(carlos == maior){
        cout << "S" << endl;
    } else {
        cout << "N" << endl;
    }

    return 0;


}