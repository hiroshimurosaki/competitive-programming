#include <bits/stdc++.h>

using namespace std;

int main(){

    int n,m;
    cin >> n >> m;
    vector<vector<int>> matriz(n,vector<int>(m));
    vector<int> maior_j(m,0);

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin >> matriz[i][j];
            if(matriz[i][j] > maior_j[j]) maior_j[j] = matriz[i][j];
        }
    }

    int sum = 0;

    for(auto  x: maior_j) sum += x;

    cout << sum << endl;

    return 0;

}